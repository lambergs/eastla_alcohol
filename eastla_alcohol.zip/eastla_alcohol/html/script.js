const card = document.getElementById('card');
const val = document.getElementById('val');
const fill = document.getElementById('fill');
const stage = document.getElementById('stage');

window.addEventListener('message', (e) => {
  const d = e.data;
  if (d.action !== 'update') return;
  if (!d.show) { card.classList.add('hidden'); return; }
  card.className = 's' + d.stage;
  val.textContent = d.bac.toFixed(3);
  fill.style.width = d.pct + '%';
  stage.textContent = d.label;
});
