local S = {} -- per player: { bac, pending = {{left, perTick}}, peak, tol, hang }

local function round(v) return math.floor(v * 10000 + 0.5) / 10000 end

local function notify(src, data)
    data.position = data.position or 'top'
    TriggerClientEvent('ox_lib:notify', src, data)
end

local function state(src)
    local s = S[src]
    if not s then
        s = { bac = 0.0, pending = {}, peak = 0.0, tol = 0.0, hang = 0 }
        S[src] = s
    end
    return s
end

local function pendingTotal(s)
    local t = 0.0
    for _, e in ipairs(s.pending) do t = t + e.left end
    return t
end

local function sync(src)
    TriggerClientEvent('eastla_alcohol:sync', src, state(src).bac)
end

local function save(src)
    local s = S[src]
    if not s then return end
    local p = exports.qbx_core:GetPlayer(src)
    if p then
        p.Functions.SetMetaData('eastla_alcohol', {
            bac = s.bac, peak = s.peak, tol = round(s.tol), ts = os.time(), hang = s.hang,
        })
    end
end

local function stageOf(v)
    local out
    for _, st in ipairs(Config.Stages) do
        if v >= st.bac then out = st end
    end
    return out
end

local function stageLabel(v)
    local st = stageOf(v)
    return st and st.label or 'Sober'
end

local function hasJob(src, jobs)
    local p = exports.qbx_core:GetPlayer(src)
    if not p then return false end
    local job = p.PlayerData.job
    if not jobs[job.name] then return false end
    if Config.RequireOnDuty and not job.onduty then return false end
    return true
end

local function nearestPlayer(src, maxDist)
    local pc = GetEntityCoords(GetPlayerPed(src))
    local best, bestDist
    for _, id in ipairs(GetPlayers()) do
        id = tonumber(id)
        if id ~= src then
            local d = #(pc - GetEntityCoords(GetPlayerPed(id)))
            if d <= maxDist and (not bestDist or d < bestDist) then
                best, bestDist = id, d
            end
        end
    end
    return best
end

local function isDriving(src)
    local ped = GetPlayerPed(src)
    local veh = GetVehiclePedIsIn(ped, false)
    return veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped
end

-- Core helpers ---------------------------------------------------------------

-- take BAC off (absorbed first, then still-unabsorbed alcohol)
local function reduce(s, amt)
    local r = math.min(s.bac, amt)
    s.bac = round(s.bac - r)
    amt = amt - r
    for i = #s.pending, 1, -1 do
        if amt <= 0 then break end
        local e = s.pending[i]
        local t = math.min(e.left, amt)
        e.left = e.left - t
        amt = amt - t
        if e.left <= 0.00001 then table.remove(s.pending, i) end
    end
end

local function setHangover(src, seconds)
    local s = state(src)
    s.hang = seconds > 0 and (os.time() + seconds) or 0
    TriggerClientEvent('eastla_alcohol:hangover', src, seconds)
end

local function addDrink(src, drink, bar)
    local s = state(src)
    local amount = drink.bac

    if bar then amount = amount * Config.BarMultiplier end

    if Config.Tolerance.enabled then
        amount = amount * (1.0 - s.tol * Config.Tolerance.maxReduction)
        s.tol = math.min(1.0, s.tol + drink.bac * Config.Tolerance.gainFactor)
    end

    if Config.Food.enabled then
        local p = exports.qbx_core:GetPlayer(src)
        local hunger = p and p.PlayerData.metadata and tonumber(p.PlayerData.metadata.hunger)
        if hunger then
            amount = amount * (1.0 - Config.Food.maxReduction * math.max(0, math.min(100, hunger)) / 100)
        end
    end

    amount = math.min(amount, Config.MaxBAC - s.bac - pendingTotal(s))
    if amount <= 0 then return end

    if Config.Absorption.enabled then
        local ticks = math.max(1, Config.Absorption.seconds / Config.TickSeconds)
        s.pending[#s.pending + 1] = { left = amount, perTick = amount / ticks }
    else
        s.bac = round(s.bac + amount)
        s.peak = math.max(s.peak, s.bac)
    end

    if s.hang > 0 then setHangover(src, 0) end -- hair of the dog
    sync(src)
    save(src)
end

local function setBAC(src, v)
    local s = state(src)
    s.bac = round(math.max(0.0, math.min(Config.MaxBAC, v)))
    s.pending = {}
    s.peak = math.max(s.peak, s.bac)
    sync(src)
    return s.bac
end

-- Load / persist -------------------------------------------------------------

local function load(src)
    local p = exports.qbx_core:GetPlayer(src)
    if not p then return end
    local meta = p.PlayerData.metadata or {}
    local m = meta.eastla_alcohol
    local s = { bac = 0.0, pending = {}, peak = 0.0, tol = 0.0, hang = 0 }

    if type(m) == 'table' then
        s.bac = tonumber(m.bac) or 0.0
        s.peak = tonumber(m.peak) or 0.0
        s.tol = tonumber(m.tol) or 0.0
        s.hang = tonumber(m.hang) or 0
        local offline = math.max(0, os.time() - (tonumber(m.ts) or os.time()))
        s.tol = math.max(0.0, s.tol - (offline / 3600) * Config.Tolerance.decayPerHour)
        if s.bac > 0 then
            s.bac = round(math.max(0.0, s.bac - (offline / 60) * Config.DecayPerMinute))
            if s.bac == 0 then s.peak = 0.0 end
        end
    elseif tonumber(meta.eastla_bac) then
        s.bac = tonumber(meta.eastla_bac)
    end

    S[src] = s
    sync(src)
    if s.hang > os.time() then
        TriggerClientEvent('eastla_alcohol:hangover', src, s.hang - os.time())
    else
        s.hang = 0
    end
end

AddEventHandler('QBCore:Server:PlayerLoaded', function(player)
    local src = player.PlayerData.source
    SetTimeout(3000, function() load(src) end)
end)

AddEventHandler('onResourceStart', function(res)
    if res ~= GetCurrentResourceName() then return end
    for _, id in ipairs(GetPlayers()) do load(tonumber(id)) end
end)

RegisterNetEvent('eastla_alcohol:request', function()
    load(source)
end)

AddEventHandler('playerDropped', function()
    local src = source
    pcall(save, src)
    S[src] = nil
end)

-- Main tick: absorb, decay, hangover, vomit ------------------------------------

CreateThread(function()
    local n = 0
    local saveEvery = math.max(1, math.floor(60 / Config.TickSeconds))
    while true do
        Wait(Config.TickSeconds * 1000)
        n = n + 1

        for src, s in pairs(S) do
            local prev = s.bac
            local active = prev > 0 or #s.pending > 0

            if Config.Tolerance.enabled and s.tol > 0 then
                s.tol = math.max(0.0, s.tol - Config.Tolerance.decayPerHour * (Config.TickSeconds / 3600))
            end

            if active then
                -- absorb
                local add = 0.0
                for i = #s.pending, 1, -1 do
                    local e = s.pending[i]
                    local a = math.min(e.perTick, e.left)
                    e.left = e.left - a
                    add = add + a
                    if e.left <= 0.00001 then table.remove(s.pending, i) end
                end

                -- decay
                local decay = Config.DecayPerMinute * (Config.TickSeconds / 60)
                s.bac = round(math.max(0.0, math.min(Config.MaxBAC, s.bac + add) - decay))
                if s.bac > s.peak then s.peak = s.bac end

                -- vomit
                if Config.Vomit.enabled and s.bac >= Config.Vomit.minBAC
                    and math.random() < Config.Vomit.chancePerTick and not isDriving(src)
                    and GetVehiclePedIsIn(GetPlayerPed(src), false) == 0 then
                    reduce(s, Config.Vomit.reduce)
                    TriggerClientEvent('eastla_alcohol:vomit', src)
                end

                -- sobered up
                if s.bac == 0 and #s.pending == 0 then
                    if Config.Hangover.enabled and s.peak >= Config.Hangover.minPeak then
                        setHangover(src, Config.Hangover.minutes * 60)
                    end
                    s.peak = 0.0
                end

                sync(src)
            end
        end

        if n % saveEvery == 0 then
            for src in pairs(S) do save(src) end
        end
    end
end)

-- Drinking (item server.export = 'eastla_alcohol.drink') ------------------------

local pendingBar = {}

-- ox_inventory may pass `slot` as a table OR as a plain slot number
local function slotBar(inventory, slot)
    if type(slot) == 'number' then
        local ok, res = pcall(function()
            return exports.ox_inventory:GetSlot(inventory.id, slot)
        end)
        slot = ok and res or nil
    end
    return type(slot) == 'table' and slot.metadata and slot.metadata.bar or nil
end

exports('drink', function(event, item, inventory, slot, data)
    local src = inventory.id
    local s = state(src)

    if Config.Debug then
        print(('[eastla_alcohol] drink event=%s item=%s src=%s slotType=%s known=%s bac=%.3f'):format(
            tostring(event), tostring(item and item.name), tostring(src), type(slot),
            tostring(Config.Drinks[item.name] ~= nil), s.bac))
    end

    local drink = Config.Drinks[item.name]
    if not drink then return end

    if event == 'usingItem' then
        if s.bac + pendingTotal(s) >= Config.MaxBAC then
            notify(src, { description = "You can't drink any more.", type = 'error' })
            return false
        end
        -- grab the bar tag now, while the item still exists
        pendingBar[src] = slotBar(inventory, slot)
    elseif event == 'usedItem' then
        local bar = slotBar(inventory, slot) or pendingBar[src]
        pendingBar[src] = nil
        addDrink(src, drink, bar)
        TriggerClientEvent('eastla_alcohol:drank', src, drink.label)
    end
end)

-- Sobering items (item server.export = 'eastla_alcohol.sober') -----------------

exports('sober', function(event, item, inventory, slot, data)
    local src = inventory.id
    local cfg = Config.Sobering[item.name]
    if not cfg then return end
    local s = state(src)

    if event == 'usingItem' then
        if cfg.onlyWhenDrunk and s.bac + pendingTotal(s) <= 0 and s.hang == 0 then
            notify(src, { description = "You don't need that right now.", type = 'error' })
            return false
        end
    elseif event == 'usedItem' then
        local had = s.bac > 0
        reduce(s, cfg.reduce)
        if cfg.cureHangover and s.hang > 0 then
            setHangover(src, 0)
            notify(src, { description = 'Your headache is gone.', type = 'success' })
        end
        if had then
            notify(src, { description = 'You feel a bit more sober.', type = 'success' })
        end
        sync(src)
        save(src)
    end
end)

-- Police drunk-driving workflow ------------------------------------------------

local function handleDUI(officer, target, bac)
    local cfg = Config.PoliceFine
    if not cfg.enabled then return end
    if GetResourceState('wasabi_police_v2') ~= 'started' then return end
    if cfg.onlyIfDriving and not isDriving(target) then return end

    local st = stageOf(bac)
    local amount = st and cfg.amounts[st.key]
    if amount and amount > 0 then
        local ok = pcall(function()
            exports['wasabi_police_v2']:finePlayer(target, amount, cfg.reason)
        end)
        if ok then
            notify(officer, { description = ('DUI fine issued: $%d'):format(amount), type = 'inform' })
            notify(target, { description = ('You were fined $%d for drunk driving.'):format(amount), type = 'error' })
        end
    end

    if cfg.jail.enabled and bac >= cfg.jail.minBAC then
        local ok = pcall(function()
            exports['wasabi_police_v2']:jailPlayer(target, cfg.jail.seconds, cfg.reason)
        end)
        if ok then
            notify(officer, { description = 'Driver jailed for DUI.', type = 'inform' })
        end
    end
end

-- Breathalyzer ---------------------------------------------------------------

local function doBreathalyzer(src)
    local cfg = Config.Breathalyzer
    local target = nearestPlayer(src, cfg.distance)
    if not target then
        notify(src, { description = 'They moved away.', type = 'error' })
        return
    end
    local v = state(target).bac
    notify(src, {
        title = 'Breathalyzer',
        description = ('BAC %.3f%% - %s'):format(v, stageLabel(v)),
        type = v >= Config.LegalLimit and 'error' or 'success',
        duration = 8000,
    })
    notify(target, { description = 'You were given a breathalyzer test.', type = 'inform' })
    if v >= Config.LegalLimit then handleDUI(src, target, v) end
end

-- NOTE: these items use consume = 0, and ox_inventory never fires the export's 'usedItem'
-- event for consume = 0 items. The export only validates ('usingItem'); the action runs from
-- the 'ox_inventory:usedItem' server event further below.
exports('breathalyzer', function(event, item, inventory, slot, data)
    local src = inventory.id
    local cfg = Config.Breathalyzer

    if event == 'usingItem' then
        if not hasJob(src, cfg.jobs) then
            notify(src, { description = "You aren't trained to use this.", type = 'error' })
            return false
        end
        if not nearestPlayer(src, cfg.distance) then
            notify(src, { description = 'Nobody close enough to test.', type = 'error' })
            return false
        end
    end
end)

-- Stomach pump ---------------------------------------------------------------

local function doStomachPump(src)
    local cfg = Config.StomachPump
    local target = nearestPlayer(src, cfg.distance)
    if not target then
        notify(src, { description = 'The patient moved away.', type = 'error' })
        return
    end
    local ts = state(target)
    ts.pending = {} -- stomach emptied: unabsorbed alcohol is gone
    reduce(ts, cfg.reduceBy)
    sync(target)
    save(target)
    TriggerClientEvent('eastla_alcohol:vomit', target)
    notify(src, { description = ('Stomach pumped. Patient BAC now %.3f%%.'):format(ts.bac), type = 'success' })
    notify(target, { description = 'You feel a lot better.', type = 'success' })
end

exports('stomach_pump', function(event, item, inventory, slot, data)
    local src = inventory.id
    local cfg = Config.StomachPump

    if event == 'usingItem' then
        if not hasJob(src, cfg.jobs) then
            notify(src, { description = "You aren't trained to use this.", type = 'error' })
            return false
        end
        local target = nearestPlayer(src, cfg.distance)
        if not target then
            notify(src, { description = 'No patient nearby.', type = 'error' })
            return false
        end
        local ts = state(target)
        if ts.bac + pendingTotal(ts) < cfg.minBAC then
            notify(src, { description = "They're not intoxicated enough to need this.", type = 'error' })
            return false
        end
    end
end)

-- Runs after a successful use, including consume = 0 items (see note above)
AddEventHandler('ox_inventory:usedItem', function(src, name)
    if name == Config.Breathalyzer.item then
        doBreathalyzer(src)
    elseif name == Config.StomachPump.item then
        doStomachPump(src)
    end
end)

-- Exports / admin ------------------------------------------------------------

exports('GetBAC', function(src) return state(src).bac end)
exports('SetBAC', function(src, v) return setBAC(src, v) end)
exports('AddBAC', function(src, v) return setBAC(src, state(src).bac + v) end)

lib.addCommand('setbac', {
    help = "Set a player's BAC (testing)",
    params = {
        { name = 'target', type = 'playerId', help = 'Server ID' },
        { name = 'value', type = 'number', help = 'e.g. 0.12' },
    },
    restricted = 'group.admin',
}, function(source, args)
    setBAC(args.target, args.value)
    save(args.target)
    notify(source, { description = ('Set BAC of %d to %.3f'):format(args.target, args.value), type = 'success' })
end)

-- DEBUG tools (Config.Debug) --------------------------------------------------
if Config.Debug then
    -- 1) logs EVERY item use ox_inventory attempts, whatever the item
    CreateThread(function()
        Wait(1000)
        local ok, err = pcall(function()
            exports.ox_inventory:registerHook('usingItem', function(payload)
                print(('[eastla_alcohol][hook] src=%s item=%s'):format(
                    tostring(payload.source), tostring(payload.item and payload.item.name)))
                return true
            end, {})
        end)
        if not ok then print('[eastla_alcohol] registerHook failed: ' .. tostring(err)) end
    end)

    -- 2) /drinktest [item]  -> runs the drink logic directly (bypasses ox_inventory)
    RegisterCommand('drinktest', function(src, args)
        if src == 0 then return print('run in-game') end
        local name = args[1] or 'beer'
        local d = Config.Drinks[name]
        if not d then return print('[eastla_alcohol] drinktest: ' .. name .. ' not in Config.Drinks') end
        addDrink(src, d, false)
        TriggerClientEvent('eastla_alcohol:drank', src, d.label)
        print(('[eastla_alcohol] drinktest ok src=%s item=%s bac=%.3f'):format(src, name, state(src).bac))
    end, false)
end

print('[eastla_alcohol] server loaded, exports registered (Debug=' .. tostring(Config.Debug) .. ')')
