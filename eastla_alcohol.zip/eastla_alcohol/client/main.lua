local bac, stage = 0.0, 0
local swerveUntil, swerveDir = 0, 0.0
local lapseUntil, lapseKind = 0, 1
local lastVeh
local hangoverUntil = 0
local aimShaking = false
local passedOut = false

local function getStage(v)
    local s = 0
    for i, st in ipairs(Config.Stages) do
        if v >= st.bac then s = i end
    end
    return s
end

local function hangoverActive()
    return hangoverUntil > 0 and GetGameTimer() < hangoverUntil
end

local function updateHud()
    if not Config.HUD then return end
    local st = Config.Stages[stage]
    SendNUIMessage({
        action = 'update',
        show = bac > 0.0,
        bac = bac,
        pct = math.min(100, (bac / Config.MaxBAC) * 100),
        stage = stage,
        label = st and st.label or 'Sober',
    })
end

local function clearEffects()
    ClearTimecycleModifier()
    StopGameplayCamShaking(true)
    ResetPedMovementClipset(cache.ped, 0.5)
    SetRunSprintMultiplierForPlayer(PlayerId(), 1.0)
    aimShaking = false
end

local function applyDrunk()
    local st = Config.Stages[stage]
    SetRunSprintMultiplierForPlayer(PlayerId(), 1.0)
    SetTimecycleModifier('drunk')
    SetTimecycleModifierStrength(st.timecycle)
    StopGameplayCamShaking(true)
    ShakeGameplayCam('DRUNK_SHAKE', st.shake)
    lib.requestAnimSet(st.clipset)
    SetPedMovementClipset(cache.ped, st.clipset, 0.5)
    aimShaking = false
end

local function applyHangover()
    ResetPedMovementClipset(cache.ped, 0.5)
    StopGameplayCamShaking(true)
    SetTimecycleModifier('drunk')
    SetTimecycleModifierStrength(Config.Hangover.blur)
    SetRunSprintMultiplierForPlayer(PlayerId(), Config.Hangover.sprintMultiplier)
    aimShaking = false
end

local function refreshEffects()
    if stage > 0 then
        applyDrunk()
    elseif hangoverActive() then
        applyHangover()
    else
        clearEffects()
    end
end

RegisterNetEvent('eastla_alcohol:sync', function(v)
    local old = stage
    bac = v
    stage = getStage(v)
    if stage ~= old then
        refreshEffects()
        if stage == 0 then
            lib.notify({ description = 'You sobered up.', type = 'success', position = 'top' })
        elseif stage > old then
            lib.notify({ description = Config.Stages[stage].msg, type = 'warning', position = 'top' })
        end
    end
    updateHud()
end)

RegisterNetEvent('eastla_alcohol:drank', function(label)
    lib.notify({ description = ('You drank a %s.'):format(label), type = 'inform', position = 'top' })
end)

RegisterNetEvent('eastla_alcohol:hangover', function(seconds)
    if seconds and seconds > 0 then
        hangoverUntil = GetGameTimer() + seconds * 1000
        lib.notify({ description = 'You have a splitting hangover.', type = 'warning', position = 'top' })
    else
        hangoverUntil = 0
    end
    refreshEffects()
end)

RegisterNetEvent('eastla_alcohol:vomit', function()
    local ped = cache.ped
    if cache.vehicle then return end
    lib.requestAnimDict('oddjobs@taxi@tie')
    TaskPlayAnim(ped, 'oddjobs@taxi@tie', 'vomit_outside', 8.0, -8.0, 5000, 0, 0, false, false, false)
end)

-- Pass out: fade to black, ragdoll for 20-30s, wake up ---------------------------
local function passOut()
    passedOut = true
    local untilT = GetGameTimer() + math.random(Config.PassOut.minMs, Config.PassOut.maxMs)
    DoScreenFadeOut(1500)
    CreateThread(function()
        while GetGameTimer() < untilT and not IsEntityDead(cache.ped) do
            if not IsPedRagdoll(cache.ped) then
                SetPedToRagdoll(cache.ped, 5000, 5000, 0, false, false, false)
            end
            Wait(500)
        end
        DoScreenFadeIn(2000)
        passedOut = false
        lib.notify({ description = 'You wake up with a pounding head.', type = 'warning', position = 'top' })
    end)
end

-- Foot effects: clipset keep-alive, stumbling, passout, ragdoll -------------------
CreateThread(function()
    local nextCheck, tick = 0, 0
    while true do
        Wait(1000)
        if stage > 0 and not passedOut then
            local ped = cache.ped
            if not IsEntityDead(ped) then
                local st = Config.Stages[stage]
                tick = tick + 1
                if tick % 3 == 0 and not IsPedRagdoll(ped) then
                    SetPedMovementClipset(ped, st.clipset, 0.5)
                end

                local onFoot = not cache.vehicle and not IsPedSwimming(ped) and not IsPedFalling(ped) and not IsPedRagdoll(ped)

                if onFoot and st.stumble > 0 and GetEntitySpeed(ped) > 0.8 and math.random() < st.stumble then
                    local a = st.stumbleAngle
                    SetEntityHeading(ped, GetEntityHeading(ped) + math.random(-a, a))
                end

                local now = GetGameTimer()
                if now >= nextCheck then
                    nextCheck = now + Config.RagdollCheckMs
                    if onFoot then
                        if Config.PassOut.enabled and st.passout > 0 and math.random() < st.passout then
                            passOut()
                        elseif st.ragdoll > 0 and math.random() < st.ragdoll then
                            SetPedToRagdoll(ped, st.ragdollMs, st.ragdollMs, 0, false, false, false)
                        end
                    end
                end
            end
        end
    end
end)

-- Hangover upkeep: expiry + shaky aim ---------------------------------------------
CreateThread(function()
    while true do
        Wait(500)
        if hangoverUntil > 0 then
            if GetGameTimer() >= hangoverUntil then
                hangoverUntil = 0
                refreshEffects()
                lib.notify({ description = 'Your hangover wore off.', type = 'success', position = 'top' })
            elseif stage == 0 then
                if IsPlayerFreeAiming(PlayerId()) then
                    if not aimShaking then
                        ShakeGameplayCam('HAND_SHAKE', Config.Hangover.aimShake)
                        aimShaking = true
                    end
                elseif aimShaking then
                    StopGameplayCamShaking(true)
                    aimShaking = false
                end
            end
        end
    end
end)

-- Drunk driving ----------------------------------------------------------------
CreateThread(function()
    local lastCheck = 0
    while true do
        local sleep = 500
        local veh = cache.vehicle
        if stage > 0 and veh and veh ~= 0 and GetPedInVehicleSeat(veh, -1) == cache.ped and not IsEntityDead(cache.ped) then
            sleep = 0
            lastVeh = veh
            local st = Config.Stages[stage]
            local now = GetGameTimer()

            if now - lastCheck > 2000 then
                lastCheck = now
                if now > swerveUntil and math.random() < st.swerve then
                    swerveUntil = now + math.random(500, 1100)
                    swerveDir = (math.random() < 0.5 and -1.0 or 1.0) * (0.5 + math.random() * 0.5)
                end
                if now > lapseUntil and math.random() < st.lapse then
                    lapseUntil = now + math.random(250, 700)
                    lapseKind = math.random(2)
                end
            end

            SetVehicleSteerBias(veh, math.sin(now / 1000.0 * st.wobbleSpeed) * st.steerBias)

            if now < swerveUntil then
                SetControlNormal(0, 59, swerveDir)
            end

            if now < lapseUntil then
                if lapseKind == 1 then
                    DisableControlAction(0, 72, true)
                    DisableControlAction(0, 76, true)
                else
                    DisableControlAction(0, 59, true)
                    DisableControlAction(0, 63, true)
                    DisableControlAction(0, 64, true)
                end
            end
        elseif lastVeh then
            if DoesEntityExist(lastVeh) then SetVehicleSteerBias(lastVeh, 0.0) end
            lastVeh = nil
        end
        Wait(sleep)
    end
end)

-- Lifecycle -------------------------------------------------------------------
AddEventHandler('onClientResourceStart', function(res)
    if res ~= GetCurrentResourceName() then return end
    if LocalPlayer.state.isLoggedIn then TriggerServerEvent('eastla_alcohol:request') end
end)

RegisterNetEvent('qbx_core:client:playerLoggedOut', function()
    bac, stage, hangoverUntil = 0.0, 0, 0
    clearEffects()
    updateHud()
end)

AddEventHandler('onResourceStop', function(res)
    if res ~= GetCurrentResourceName() then return end
    clearEffects()
    if passedOut then DoScreenFadeIn(500) end
    if lastVeh and DoesEntityExist(lastVeh) then SetVehicleSteerBias(lastVeh, 0.0) end
end)
