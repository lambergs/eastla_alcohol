Config = {}

-- BAC is stored as a percentage (0.08 = legal-limit style number)
Config.Debug          = false     -- prints drink events to server console
Config.MaxBAC          = 0.40     -- hard cap, can't drink past this
Config.DecayPerMinute  = 0.0025   -- real liver rate is ~0.015/HOUR (0.00025/min); this is 10x faster so a night fits a play session
Config.TickSeconds     = 5        -- server decay/absorb/sync interval
Config.LegalLimit      = 0.05     -- PH legal driving limit (RA 10586). breathalyzer shows red at/above this
Config.HUD             = true     -- small BAC card while you have alcohol in you

-- Drinks: key = ox_inventory item name
-- Scale: 1 standard drink (14 g ethanol: 330 ml beer, 150 ml wine, 45 ml spirit) ~= 0.020 BAC.
-- Bottles are "several big pours" in one use, so they are ~4-5 standard drinks.
Config.Drinks = {
    -- beer / single servings
    beer              = { label = 'beer', bac = 0.020 },
    vodka_shot        = { label = 'vodka shot', bac = 0.020 },
    tequila_shot      = { label = 'tequila shot', bac = 0.020 },
    whiskey_glass     = { label = 'whiskey', bac = 0.025 },   -- generous pour
    rum_glass         = { label = 'rum', bac = 0.020 },
    wine_glass        = { label = 'wine', bac = 0.020 },
    champagne_glass   = { label = 'champagne', bac = 0.018 },

    -- cocktails
    mojito            = { label = 'mojito', bac = 0.020 },
    martini           = { label = 'martini', bac = 0.035 },    -- ~2 shots of spirit
    bloody_mary       = { label = 'bloody mary', bac = 0.020 },
    sex_on_the_beach  = { label = 'sex on the beach', bac = 0.018 },
    pina_colada       = { label = 'pina colada', bac = 0.020 },

    -- bottles
    vodka             = { label = 'vodka', bac = 0.100 },
    whiskey           = { label = 'whiskey', bac = 0.100 },
    tequila           = { label = 'tequila', bac = 0.100 },
    rum               = { label = 'rum', bac = 0.100 },
    wine              = { label = 'wine', bac = 0.080 },

    -- your server's existing items
    sanmiguelbeer       = { label = 'san miguel', bac = 0.015 },  -- light beer
    royal_flush_whiskey = { label = 'whiskey', bac = 0.100 },
    high_roller_vodka   = { label = 'vodka', bac = 0.100 },
    lucky_7s_tequila    = { label = 'tequila', bac = 0.100 },
    blackjack_bourbon   = { label = 'bourbon', bac = 0.100 },
    expensive_champagne = { label = 'champagne', bac = 0.080 },
}

-- BAR: drinks whose item metadata has bar = true hit harder.
-- Your bar job must create the item with metadata { bar = true } when serving it.
Config.BarMultiplier = 1.25

-- SOBERING ITEMS (ox_inventory item name -> effect). reduce = BAC removed.
-- Realistic: water/coffee/energy drinks do NOT burn off alcohol, they only make you feel more alert,
-- so the effect is tiny. The pill is fictional, so it is the only real "sober up" item.
Config.Sobering = {
    water        = { reduce = 0.002 },
    coffee       = { reduce = 0.003 },
    energy_drink = { reduce = 0.003 },
    sober_pill   = { reduce = 0.060, cureHangover = true, onlyWhenDrunk = true },
}

-- GRADUAL ABSORPTION: a drink's BAC rises over time instead of instantly
Config.Absorption = { enabled = true, seconds = 240 }   -- real peak is 30-90 min; ~4 min at the 10x time scale

-- TOLERANCE: regular drinkers feel less. tolerance 0..1, stored per character
Config.Tolerance = {
    enabled      = true,
    gainFactor   = 0.5,    -- tolerance gained per drink = drink.bac * this
    maxReduction = 0.30,   -- at full tolerance, drinks add 30% less BAC
    decayPerHour = 0.02,   -- tolerance lost per real hour (also while offline)
}

-- FOOD: full stomach slows the hit. Reads qbx 'hunger' metadata (100 = full)
Config.Food = { enabled = true, maxReduction = 0.30 }

-- HANGOVER: after sobering up from a big night
Config.Hangover = {
    enabled          = true,
    minPeak          = 0.12,   -- peak BAC needed to earn one (heavy night)
    minutes          = 20,
    blur             = 0.15,   -- screen blur strength
    sprintMultiplier = 0.90,   -- slower sprint
    aimShake         = 0.40,   -- hand shake while aiming
}

-- VOMITING: server-rolled every tick while very drunk, lowers BAC a bit
Config.Vomit = { enabled = true, minBAC = 0.18, chancePerTick = 0.012, reduce = 0.008 }

-- PASS OUT: Wasted players may black out on foot (chance is per stage, see below)
Config.PassOut = { enabled = true, minMs = 20000, maxMs = 30000 }

-- POLICE: a failed breathalyzer (>= LegalLimit) can fine / jail through wasabi_police_v2
Config.PoliceFine = {
    enabled       = true,
    onlyIfDriving = true,   -- only if the tested person is driving a vehicle
    reason        = 'DUI - Driving under the influence',
    amounts       = { tipsy = 1500, drunk = 2000, very_drunk = 4000, wasted = 6000 },
    jail          = { enabled = false, minBAC = 0.20, seconds = 300 },
}

-- Tool jobs (job name = true)
Config.RequireOnDuty = true

Config.Breathalyzer = {
    item     = 'breathalyzer',
    jobs     = { police = true, ambulance = true },
    distance = 3.0,
}

Config.StomachPump = {
    item     = 'stomach_pump',
    jobs     = { ambulance = true },
    distance = 3.0,
    minBAC   = 0.12,   -- patient must be at least this drunk
    reduceBy = 0.15,   -- BAC removed per pump (also empties unabsorbed alcohol)
}

-- Stages (highest matching wins)
-- Vehicle:  steerBias = constant wobble, swerve = chance every 2s of a random swerve,
--           lapse = chance every 2s of a "slow reaction" window (brake or steering ignored briefly)
-- On foot:  stumble = chance per second (while moving) of heading drift,
--           ragdoll / passout = chance per RagdollCheckMs
Config.RagdollCheckMs = 8000

Config.Stages = {
    {
        key = 'tipsy', label = 'Tipsy', bac = 0.03,
        msg = 'You feel a little tipsy.',
        clipset = 'move_m@drunk@slightlydrunk', timecycle = 0.20, shake = 0.05,
        steerBias = 0.03, wobbleSpeed = 1.5, swerve = 0.00, lapse = 0.00,
        stumble = 0.00, stumbleAngle = 0, ragdoll = 0.00, ragdollMs = 0, passout = 0.00,
    },
    {
        key = 'drunk', label = 'Drunk', bac = 0.08,
        msg = "You're drunk. Maybe don't drive.",
        clipset = 'move_m@drunk@moderatedrunk', timecycle = 0.45, shake = 0.15,
        steerBias = 0.09, wobbleSpeed = 1.8, swerve = 0.10, lapse = 0.10,
        stumble = 0.12, stumbleAngle = 20, ragdoll = 0.00, ragdollMs = 0, passout = 0.00,
    },
    {
        key = 'very_drunk', label = 'Very Drunk', bac = 0.15,
        msg = "You're very drunk. The world won't stop spinning.",
        clipset = 'move_m@drunk@verydrunk', timecycle = 0.75, shake = 0.35,
        steerBias = 0.16, wobbleSpeed = 2.2, swerve = 0.25, lapse = 0.20,
        stumble = 0.30, stumbleAngle = 35, ragdoll = 0.10, ragdollMs = 3000, passout = 0.00,
    },
    {
        key = 'wasted', label = 'Wasted', bac = 0.25,
        msg = "You're completely wasted. You need help.",
        clipset = 'move_m@drunk@verydrunk', timecycle = 1.00, shake = 0.70,
        steerBias = 0.26, wobbleSpeed = 2.6, swerve = 0.45, lapse = 0.35,
        stumble = 0.50, stumbleAngle = 55, ragdoll = 0.30, ragdollMs = 6000, passout = 0.12,
    },
}
