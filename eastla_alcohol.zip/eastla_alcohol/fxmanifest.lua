fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'eastla_alcohol'
author 'StreetKings'
description 'Realistic alcohol system - BAC, drunk stages, drunk driving, ragdoll, breathalyzer, stomach pump'
version '1.0.0'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua',
}

client_scripts { 'client/main.lua' }
server_scripts { 'server/main.lua' }

ui_page 'html/index.html'
files {
    'html/index.html',
    'html/style.css',
    'html/script.js',
}

dependencies { 'ox_lib', 'ox_inventory', 'qbx_core' }
