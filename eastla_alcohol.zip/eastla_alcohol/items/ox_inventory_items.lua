-- Paste into ox_inventory/data/items.lua (replace your existing entries for these items)
-- If you'd rather keep your current definitions, just add to each one:
--     consume = 1,  server = { export = 'eastla_alcohol.drink' },
-- and keep/add your own client anim/prop. Prop offsets may need tweaking.

['beer'] = {
    label = 'Beer', weight = 350, stack = true, close = true, consume = 1,
    client = {
        anim = { dict = 'mp_player_intdrink', clip = 'loop_bottle' },
        prop = { model = `prop_amb_beer_bottle`, pos = vec3(0.03, 0.03, 0.02), rot = vec3(0.0, 0.0, -1.5) },
        usetime = 3500, cancel = true,
    },
    server = { export = 'eastla_alcohol.drink' },
},

['vodka'] = {
    label = 'Vodka', weight = 700, stack = true, close = true, consume = 1,
    client = {
        anim = { dict = 'mp_player_intdrink', clip = 'loop_bottle' },
        prop = { model = `prop_vodka_bottle`, pos = vec3(0.03, 0.03, 0.02), rot = vec3(0.0, 0.0, -1.5) },
        usetime = 4000, cancel = true,
    },
    server = { export = 'eastla_alcohol.drink' },
},

['vodka_shot'] = {
    label = 'Vodka Shot', weight = 150, stack = true, close = true, consume = 1,
    client = {
        anim = { dict = 'amb@world_human_drinking@coffee@male@idle_a', clip = 'idle_a' },
        prop = { model = `prop_shots_glass_cs`, bone = 28422, pos = vec3(0.0, 0.0, 0.0), rot = vec3(0.0, 0.0, 0.0) },
        usetime = 2000, cancel = true,
    },
    server = { export = 'eastla_alcohol.drink' },
},

['whiskey'] = {
    label = 'Whiskey', weight = 700, stack = true, close = true, consume = 1,
    client = {
        anim = { dict = 'mp_player_intdrink', clip = 'loop_bottle' },
        prop = { model = `prop_whiskey_bottle`, pos = vec3(0.03, 0.03, 0.02), rot = vec3(0.0, 0.0, -1.5) },
        usetime = 4000, cancel = true,
    },
    server = { export = 'eastla_alcohol.drink' },
},

['whiskey_glass'] = {
    label = 'Glass of Whiskey', weight = 250, stack = true, close = true, consume = 1,
    client = {
        anim = { dict = 'amb@world_human_drinking@coffee@male@idle_a', clip = 'idle_a' },
        prop = { model = `prop_drink_whisky`, bone = 28422, pos = vec3(0.0, 0.0, 0.0), rot = vec3(0.0, 0.0, 0.0) },
        usetime = 3000, cancel = true,
    },
    server = { export = 'eastla_alcohol.drink' },
},

['tequila'] = {
    label = 'Tequila', weight = 700, stack = true, close = true, consume = 1,
    client = {
        anim = { dict = 'mp_player_intdrink', clip = 'loop_bottle' },
        prop = { model = `prop_tequila_bottle`, pos = vec3(0.03, 0.03, 0.02), rot = vec3(0.0, 0.0, -1.5) },
        usetime = 4000, cancel = true,
    },
    server = { export = 'eastla_alcohol.drink' },
},

['tequila_shot'] = {
    label = 'Tequila Shot', weight = 150, stack = true, close = true, consume = 1,
    client = {
        anim = { dict = 'amb@world_human_drinking@coffee@male@idle_a', clip = 'idle_a' },
        prop = { model = `prop_shots_glass_cs`, bone = 28422, pos = vec3(0.0, 0.0, 0.0), rot = vec3(0.0, 0.0, 0.0) },
        usetime = 2000, cancel = true,
    },
    server = { export = 'eastla_alcohol.drink' },
},

['wine'] = {
    label = 'Wine', weight = 700, stack = true, close = true, consume = 1,
    client = {
        anim = { dict = 'mp_player_intdrink', clip = 'loop_bottle' },
        prop = { model = `prop_wine_red`, pos = vec3(0.03, 0.03, 0.02), rot = vec3(0.0, 0.0, -1.5) },
        usetime = 4000, cancel = true,
    },
    server = { export = 'eastla_alcohol.drink' },
},

['wine_glass'] = {
    label = 'Glass of Wine', weight = 250, stack = true, close = true, consume = 1,
    client = {
        anim = { dict = 'amb@world_human_drinking@coffee@male@idle_a', clip = 'idle_a' },
        prop = { model = `prop_drink_redwine`, bone = 28422, pos = vec3(0.0, 0.0, 0.0), rot = vec3(0.0, 0.0, 0.0) },
        usetime = 3000, cancel = true,
    },
    server = { export = 'eastla_alcohol.drink' },
},

['rum'] = {
    label = 'Rum', weight = 700, stack = true, close = true, consume = 1,
    client = {
        anim = { dict = 'mp_player_intdrink', clip = 'loop_bottle' },
        prop = { model = `prop_ld_flow_bottle`, pos = vec3(0.03, 0.03, 0.02), rot = vec3(0.0, 0.0, -1.5) },
        usetime = 4000, cancel = true,
    },
    server = { export = 'eastla_alcohol.drink' },
},

['rum_glass'] = {
    label = 'Glass of Rum', weight = 250, stack = true, close = true, consume = 1,
    client = {
        anim = { dict = 'amb@world_human_drinking@coffee@male@idle_a', clip = 'idle_a' },
        prop = { model = `prop_drink_whisky`, bone = 28422, pos = vec3(0.0, 0.0, 0.0), rot = vec3(0.0, 0.0, 0.0) },
        usetime = 3000, cancel = true,
    },
    server = { export = 'eastla_alcohol.drink' },
},

['champagne_glass'] = {
    label = 'Glass of Champagne', weight = 250, stack = true, close = true, consume = 1,
    client = {
        anim = { dict = 'amb@world_human_drinking@coffee@male@idle_a', clip = 'idle_a' },
        prop = { model = `prop_drink_champ`, bone = 28422, pos = vec3(0.0, 0.0, 0.0), rot = vec3(0.0, 0.0, 0.0) },
        usetime = 3000, cancel = true,
    },
    server = { export = 'eastla_alcohol.drink' },
},

['mojito'] = {
    label = 'Mojito', weight = 300, stack = true, close = true, consume = 1,
    client = {
        anim = { dict = 'amb@world_human_drinking@coffee@male@idle_a', clip = 'idle_a' },
        prop = { model = `prop_cocktail`, bone = 28422, pos = vec3(0.0, 0.0, 0.0), rot = vec3(0.0, 0.0, 0.0) },
        usetime = 3500, cancel = true,
    },
    server = { export = 'eastla_alcohol.drink' },
},

['martini'] = {
    label = 'Martini', weight = 300, stack = true, close = true, consume = 1,
    client = {
        anim = { dict = 'amb@world_human_drinking@coffee@male@idle_a', clip = 'idle_a' },
        prop = { model = `prop_cocktail`, bone = 28422, pos = vec3(0.0, 0.0, 0.0), rot = vec3(0.0, 0.0, 0.0) },
        usetime = 3500, cancel = true,
    },
    server = { export = 'eastla_alcohol.drink' },
},

['bloody_mary'] = {
    label = 'Bloody Mary', weight = 300, stack = true, close = true, consume = 1,
    client = {
        anim = { dict = 'amb@world_human_drinking@coffee@male@idle_a', clip = 'idle_a' },
        prop = { model = `prop_cocktail`, bone = 28422, pos = vec3(0.0, 0.0, 0.0), rot = vec3(0.0, 0.0, 0.0) },
        usetime = 3500, cancel = true,
    },
    server = { export = 'eastla_alcohol.drink' },
},

['sex_on_the_beach'] = {
    label = 'Sex on the Beach', weight = 300, stack = true, close = true, consume = 1,
    client = {
        anim = { dict = 'amb@world_human_drinking@coffee@male@idle_a', clip = 'idle_a' },
        prop = { model = `prop_cocktail`, bone = 28422, pos = vec3(0.0, 0.0, 0.0), rot = vec3(0.0, 0.0, 0.0) },
        usetime = 3500, cancel = true,
    },
    server = { export = 'eastla_alcohol.drink' },
},

['pina_colada'] = {
    label = 'Pina Colada', weight = 300, stack = true, close = true, consume = 1,
    client = {
        anim = { dict = 'amb@world_human_drinking@coffee@male@idle_a', clip = 'idle_a' },
        prop = { model = `prop_cocktail`, bone = 28422, pos = vec3(0.0, 0.0, 0.0), rot = vec3(0.0, 0.0, 0.0) },
        usetime = 3500, cancel = true,
    },
    server = { export = 'eastla_alcohol.drink' },
},

['breathalyzer'] = {
    label = 'Breathalyzer', weight = 300, stack = false, close = true, consume = 0,
    description = "Test the nearest person's BAC.",
    client = {
        anim = { dict = 'amb@code_human_police_investigate@idle_a', clip = 'idle_b' },
        usetime = 3000, cancel = true,
    },
    server = { export = 'eastla_alcohol.breathalyzer' },
},

['stomach_pump'] = {
    label = 'Stomach Pump Kit', weight = 1500, stack = false, close = true, consume = 0,
    description = 'Emergency stomach lavage.',
    client = {
        anim = { dict = 'mini@repair', clip = 'fixing_a_ped' },
        usetime = 9000, cancel = true,
    },
    server = { export = 'eastla_alcohol.stomach_pump' },
},

-- ===== SOBERING ITEMS =====
-- If you already have water / coffee / energy_drink, DON'T duplicate them: just make sure each has
--   server = { export = 'eastla_alcohol.sober' }
-- (an item can only have one server export; if yours already has one, tell me and I'll chain it).

['sober_pill'] = {
    label = 'Sober-Up Pill', weight = 50, stack = true, close = true, consume = 1,
    description = 'Clears your head fast.',
    client = {
        anim = { dict = 'mp_suicide', clip = 'pill' },
        usetime = 2000, cancel = true,
    },
    server = { export = 'eastla_alcohol.sober' },
},

['coffee'] = {
    label = 'Coffee', weight = 200, stack = true, close = true, consume = 1,
    client = {
        anim = { dict = 'amb@world_human_drinking@coffee@male@idle_a', clip = 'idle_a' },
        prop = { model = `p_amb_coffeecup_01`, bone = 28422, pos = vec3(0.0, 0.0, 0.0), rot = vec3(0.0, 0.0, 0.0) },
        usetime = 3000, cancel = true,
    },
    server = { export = 'eastla_alcohol.sober' },
},

['water'] = {
    label = 'Water', weight = 300, stack = true, close = true, consume = 1,
    client = {
        anim = { dict = 'mp_player_intdrink', clip = 'loop_bottle' },
        prop = { model = `prop_ld_flow_bottle`, pos = vec3(0.03, 0.03, 0.02), rot = vec3(0.0, 0.0, -1.5) },
        usetime = 3000, cancel = true,
    },
    server = { export = 'eastla_alcohol.sober' },
},

['energy_drink'] = {
    label = 'Energy Drink', weight = 300, stack = true, close = true, consume = 1,
    client = {
        anim = { dict = 'mp_player_intdrink', clip = 'loop_bottle' },
        prop = { model = `prop_energy_drink`, pos = vec3(0.03, 0.03, 0.02), rot = vec3(0.0, 0.0, -1.5) },
        usetime = 3000, cancel = true,
    },
    server = { export = 'eastla_alcohol.sober' },
},
