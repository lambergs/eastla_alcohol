-- Your live ox_inventory/data/items.lua already has these items, but WITHOUT the drink export,
-- so using them never reaches eastla_alcohol. REPLACE your existing entries with these.

['sanmiguelbeer'] = {
    label = 'Sanmig Lights',
    weight = 100,
    stack = true,
    consume = 1,
    degrade = 1440,
    decay = true,
    metadata = { decay = 100 },
    client = {
        status = { thirst = 330000 },
        anim = { dict = 'mp_player_intdrink', clip = 'loop_bottle' },
        prop = { model = `prop_beer_bottle`, pos = vec3(0.03, 0.03, 0.02), rot = vec3(0.0, 0.0, -1.5) },
        usetime = 3500,
        cancel = true,
        notification = 'Sanmig Lights'
    },
    server = { export = 'eastla_alcohol.drink' },
},

['royal_flush_whiskey'] = {
    label = 'Royal Flush Whiskey', weight = 10, stack = true, consume = 1,
    client = {
        anim = { dict = 'mp_player_intdrink', clip = 'loop_bottle' },
        prop = { model = `prop_whiskey_bottle`, pos = vec3(0.03, 0.03, 0.02), rot = vec3(0.0, 0.0, -1.5) },
        usetime = 4000, cancel = true,
    },
    server = { export = 'eastla_alcohol.drink' },
},

['high_roller_vodka'] = {
    label = 'High Roller Vodka', weight = 10, stack = true, consume = 1,
    client = {
        anim = { dict = 'mp_player_intdrink', clip = 'loop_bottle' },
        prop = { model = `prop_vodka_bottle`, pos = vec3(0.03, 0.03, 0.02), rot = vec3(0.0, 0.0, -1.5) },
        usetime = 4000, cancel = true,
    },
    server = { export = 'eastla_alcohol.drink' },
},

['lucky_7s_tequila'] = {
    label = "Lucky 7's Tequila", weight = 10, stack = true, consume = 1,
    client = {
        anim = { dict = 'mp_player_intdrink', clip = 'loop_bottle' },
        prop = { model = `prop_tequila_bottle`, pos = vec3(0.03, 0.03, 0.02), rot = vec3(0.0, 0.0, -1.5) },
        usetime = 4000, cancel = true,
    },
    server = { export = 'eastla_alcohol.drink' },
},

['blackjack_bourbon'] = {
    label = 'Blackjack Bourbon', weight = 10, stack = true, consume = 1,
    client = {
        anim = { dict = 'mp_player_intdrink', clip = 'loop_bottle' },
        prop = { model = `prop_whiskey_bottle`, pos = vec3(0.03, 0.03, 0.02), rot = vec3(0.0, 0.0, -1.5) },
        usetime = 4000, cancel = true,
    },
    server = { export = 'eastla_alcohol.drink' },
},

['expensive_champagne'] = {
    label = 'Expensive Champagne', weight = 10, stack = true, consume = 1,
    client = {
        anim = { dict = 'mp_player_intdrink', clip = 'loop_bottle' },
        prop = { model = `prop_drink_champ`, pos = vec3(0.03, 0.03, 0.02), rot = vec3(0.0, 0.0, -1.5) },
        usetime = 3500, cancel = true,
    },
    server = { export = 'eastla_alcohol.drink' },
},
